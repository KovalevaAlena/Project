# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'OrderWindow.ui'
##
## Created by: Qt User Interface Compiler version 6.6.0
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide6.QtCore import (QCoreApplication, QDate, QDateTime, QLocale,
    QMetaObject, QObject, QPoint, QRect,
    QSize, QTime, QUrl, Qt)
from PySide6.QtGui import (QBrush, QColor, QConicalGradient, QCursor,
    QFont, QFontDatabase, QGradient, QIcon,
    QImage, QKeySequence, QLinearGradient, QPainter,
    QPalette, QPixmap, QRadialGradient, QTransform)
from PySide6.QtWidgets import (QApplication, QDialog, QHBoxLayout, QHeaderView,
    QLabel, QPushButton, QSizePolicy, QSpacerItem,
    QTableView, QVBoxLayout, QWidget)
import res2_rc

class Ui_Dialog(object):
    def setupUi(self, Dialog):
        if not Dialog.objectName():
            Dialog.setObjectName(u"Dialog")
        Dialog.resize(699, 567)
        Dialog.setStyleSheet(u"background-color: rgb(18, 25, 27)")
        self.widget = QWidget(Dialog)
        self.widget.setObjectName(u"widget")
        self.widget.setGeometry(QRect(4, 7, 691, 551))
        self.verticalLayout = QVBoxLayout(self.widget)
        self.verticalLayout.setObjectName(u"verticalLayout")
        self.verticalLayout.setContentsMargins(0, 0, 0, 0)
        self.horizontalLayout_4 = QHBoxLayout()
        self.horizontalLayout_4.setObjectName(u"horizontalLayout_4")
        self.BackButton = QPushButton(self.widget)
        self.BackButton.setObjectName(u"BackButton")
        self.BackButton.setStyleSheet(u"QPushButton {\n"
"background-color: rgb(30, 36, 43);\n"
"border-radius: 15px;\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"	background-color: rgba(255, 255, 255, 30);\n"
"}\n"
"\n"
"QPushButton:pressed {\n"
"	background-color: rgba(255, 255, 255, 50)\n"
"}")
        icon = QIcon()
        icon.addFile(u":/icons2/icons/back.svg", QSize(), QIcon.Normal, QIcon.Off)
        self.BackButton.setIcon(icon)
        self.BackButton.setIconSize(QSize(45, 45))

        self.horizontalLayout_4.addWidget(self.BackButton)

        self.horizontalSpacer = QSpacerItem(40, 20, QSizePolicy.Expanding, QSizePolicy.Minimum)

        self.horizontalLayout_4.addItem(self.horizontalSpacer)


        self.verticalLayout.addLayout(self.horizontalLayout_4)

        self.horizontalLayout = QHBoxLayout()
        self.horizontalLayout.setObjectName(u"horizontalLayout")
        self.MenuTable = QTableView(self.widget)
        self.MenuTable.setObjectName(u"MenuTable")
        self.MenuTable.setStyleSheet(u"QTableView {\n"
"	background-color: rgb(30, 36, 43);\n"
"	border: 1px solid rgb(30, 36, 43);\n"
"	border-radius: 10px;\n"
"}\n"
"\n"
"QTableView:section {\n"
"}")

        self.horizontalLayout.addWidget(self.MenuTable)

        self.OrderTable = QTableView(self.widget)
        self.OrderTable.setObjectName(u"OrderTable")
        self.OrderTable.setStyleSheet(u"QTableView {\n"
"	background-color: rgb(30, 36, 43);\n"
"	border: 1px solid rgb(30, 36, 43);\n"
"	border-radius: 10px;\n"
"}")

        self.horizontalLayout.addWidget(self.OrderTable)


        self.verticalLayout.addLayout(self.horizontalLayout)

        self.horizontalLayout_2 = QHBoxLayout()
        self.horizontalLayout_2.setObjectName(u"horizontalLayout_2")
        self.label_2 = QLabel(self.widget)
        self.label_2.setObjectName(u"label_2")
        self.label_2.setMinimumSize(QSize(20, 20))
        self.label_2.setStyleSheet(u"font: 14pt \"Arial\";\n"
"color: rgb(255, 255, 255);")
        self.label_2.setIndent(232)

        self.horizontalLayout_2.addWidget(self.label_2)

        self.ItogLable = QLabel(self.widget)
        self.ItogLable.setObjectName(u"ItogLable")
        self.ItogLable.setStyleSheet(u"font: 14pt \"Arial\";\n"
"color: rgb(255, 255, 255);\n"
"background-color: rgba(255, 255, 255, 50);\n"
"")

        self.horizontalLayout_2.addWidget(self.ItogLable)


        self.verticalLayout.addLayout(self.horizontalLayout_2)

        self.horizontalLayout_3 = QHBoxLayout()
        self.horizontalLayout_3.setObjectName(u"horizontalLayout_3")
        self.DeleteButton = QPushButton(self.widget)
        self.DeleteButton.setObjectName(u"DeleteButton")
        self.DeleteButton.setStyleSheet(u"QPushButton {\n"
"background-color: rgb(30, 36, 43);\n"
"border-radius: 15px;\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"	background-color: rgba(255, 255, 255, 30);\n"
"}\n"
"\n"
"QPushButton:pressed {\n"
"	background-color: rgba(255, 255, 255, 50)\n"
"}")
        icon1 = QIcon()
        icon1.addFile(u":/icons2/icons/delete.svg", QSize(), QIcon.Normal, QIcon.Off)
        self.DeleteButton.setIcon(icon1)
        self.DeleteButton.setIconSize(QSize(45, 45))

        self.horizontalLayout_3.addWidget(self.DeleteButton)

        self.AddButton = QPushButton(self.widget)
        self.AddButton.setObjectName(u"AddButton")
        self.AddButton.setStyleSheet(u"QPushButton {\n"
"background-color: rgb(30, 36, 43);\n"
"border-radius: 15px;\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"	background-color: rgba(255, 255, 255, 30);\n"
"}\n"
"\n"
"QPushButton:pressed {\n"
"	background-color: rgba(255, 255, 255, 50)\n"
"}")
        icon2 = QIcon()
        icon2.addFile(u":/icons2/icons/add.svg", QSize(), QIcon.Normal, QIcon.Off)
        self.AddButton.setIcon(icon2)
        self.AddButton.setIconSize(QSize(45, 45))

        self.horizontalLayout_3.addWidget(self.AddButton)


        self.verticalLayout.addLayout(self.horizontalLayout_3)

        self.pushButton_3 = QPushButton(self.widget)
        self.pushButton_3.setObjectName(u"pushButton_3")
        self.pushButton_3.setStyleSheet(u"QPushButton {\n"
"background-color:rgb(0, 218, 160);\n"
"border-style: outset; \n"
"border-radius: 15px; \n"
"border-color: rgb(0, 255, 191);\n"
"font: 700 14pt \"Arial\";\n"
"color: rgb(255, 255, 255);\n"
"padding: 4px; \n"
"}\n"
"\n"
"QPushButton:hover {\n"
"	background-color: rgb(0, 239, 175);\n"
"}\n"
"\n"
"QPushButton:pressed {\n"
"	background-color: rgb(0, 255, 187);\n"
"}")

        self.verticalLayout.addWidget(self.pushButton_3)


        self.retranslateUi(Dialog)

        QMetaObject.connectSlotsByName(Dialog)
    # setupUi

    def retranslateUi(self, Dialog):
        Dialog.setWindowTitle(QCoreApplication.translate("Dialog", u"Dialog", None))
        self.BackButton.setText("")
        self.label_2.setText(QCoreApplication.translate("Dialog", u"\u0418\u0442\u043e\u0433\u043e:", None))
        self.ItogLable.setText(QCoreApplication.translate("Dialog", u"sss", None))
        self.DeleteButton.setText("")
        self.AddButton.setText("")
        self.pushButton_3.setText(QCoreApplication.translate("Dialog", u"\u041e\u043f\u043b\u0430\u0442\u0430", None))
    # retranslateUi

