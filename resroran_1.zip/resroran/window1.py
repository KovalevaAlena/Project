# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'window1.ui'
##
## Created by: Qt User Interface Compiler version 6.6.0
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide6.QtCore import (QCoreApplication, QDate, QDateTime, QLocale,
    QMetaObject, QObject, QPoint, QRect,
    QSize, QTime, QUrl, Qt)
from PySide6.QtGui import (QBrush, QColor, QConicalGradient, QCursor,
    QFont, QFontDatabase, QGradient, QIcon,
    QImage, QKeySequence, QLinearGradient, QPainter,
    QPalette, QPixmap, QRadialGradient, QTransform)
from PySide6.QtWidgets import (QApplication, QDialog, QFrame, QGridLayout,
    QHBoxLayout, QLabel, QPushButton, QSizePolicy,
    QSpacerItem, QVBoxLayout, QWidget)
import res_rc

class Ui_Dialog(object):
    def setupUi(self, Dialog):
        if not Dialog.objectName():
            Dialog.setObjectName(u"Dialog")
        Dialog.resize(745, 691)
        Dialog.setStyleSheet(u"background-color: rgb(18, 25, 27);")
        self.widget = QWidget(Dialog)
        self.widget.setObjectName(u"widget")
        self.widget.setGeometry(QRect(12, 10, 721, 671))
        self.gridLayout_9 = QGridLayout(self.widget)
        self.gridLayout_9.setObjectName(u"gridLayout_9")
        self.gridLayout_9.setContentsMargins(0, 0, 0, 0)
        self.horizontalLayout_10 = QHBoxLayout()
        self.horizontalLayout_10.setObjectName(u"horizontalLayout_10")
        self.label = QLabel(self.widget)
        self.label.setObjectName(u"label")
        self.label.setStyleSheet(u"color: rgb(255, 255, 255);\n"
"font: 700 22pt \"Arial\";")

        self.horizontalLayout_10.addWidget(self.label)

        self.HelloLable = QLabel(self.widget)
        self.HelloLable.setObjectName(u"HelloLable")
        self.HelloLable.setStyleSheet(u"color: rgb(255, 255, 255);\n"
"font: 700 22pt \"Arial\";")

        self.horizontalLayout_10.addWidget(self.HelloLable)


        self.gridLayout_9.addLayout(self.horizontalLayout_10, 0, 0, 1, 1)

        self.horizontalLayout_9 = QHBoxLayout()
        self.horizontalLayout_9.setObjectName(u"horizontalLayout_9")
        self.ProfilButton = QPushButton(self.widget)
        self.ProfilButton.setObjectName(u"ProfilButton")
        self.ProfilButton.setStyleSheet(u"QPushButton {\n"
"background-color: rgb(30, 36, 43);\n"
"border-radius: 15px;\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"	background-color: rgba(255, 255, 255, 30);\n"
"}\n"
"\n"
"QPushButton:pressed {\n"
"	background-color: rgba(255, 255, 255, 50)\n"
"}")
        icon = QIcon()
        icon.addFile(u":/icons/icons/person.svg", QSize(), QIcon.Normal, QIcon.Off)
        self.ProfilButton.setIcon(icon)
        self.ProfilButton.setIconSize(QSize(35, 35))

        self.horizontalLayout_9.addWidget(self.ProfilButton)

        self.QuestionButton = QPushButton(self.widget)
        self.QuestionButton.setObjectName(u"QuestionButton")
        self.QuestionButton.setStyleSheet(u"QPushButton {\n"
"background-color: rgb(30, 36, 43);\n"
"border-radius: 15px;\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"	background-color: rgba(255, 255, 255, 30);\n"
"}\n"
"\n"
"QPushButton:pressed {\n"
"	background-color: rgba(255, 255, 255, 50)\n"
"}")
        icon1 = QIcon()
        icon1.addFile(u":/icons/icons/question.svg", QSize(), QIcon.Normal, QIcon.Off)
        self.QuestionButton.setIcon(icon1)
        self.QuestionButton.setIconSize(QSize(35, 35))

        self.horizontalLayout_9.addWidget(self.QuestionButton)

        self.InfoButton = QPushButton(self.widget)
        self.InfoButton.setObjectName(u"InfoButton")
        self.InfoButton.setStyleSheet(u"QPushButton {\n"
"background-color: rgb(30, 36, 43);\n"
"border-radius: 15px;\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"	background-color: rgba(255, 255, 255, 30);\n"
"}\n"
"\n"
"QPushButton:pressed {\n"
"	background-color: rgba(255, 255, 255, 50)\n"
"}")
        icon2 = QIcon()
        icon2.addFile(u":/icons/icons/info.svg", QSize(), QIcon.Normal, QIcon.Off)
        self.InfoButton.setIcon(icon2)
        self.InfoButton.setIconSize(QSize(35, 35))

        self.horizontalLayout_9.addWidget(self.InfoButton)


        self.gridLayout_9.addLayout(self.horizontalLayout_9, 0, 1, 1, 1)

        self.Table1Frame = QFrame(self.widget)
        self.Table1Frame.setObjectName(u"Table1Frame")
        self.Table1Frame.setMinimumSize(QSize(312, 216))
        self.Table1Frame.setStyleSheet(u"background-color: rgb(30, 36, 43);\n"
"border-style: outset; \n"
"border-radius: 15px; \n"
"border-color: rgb(0, 255, 191);\n"
"font: 700 14pt \"Arial\";\n"
"color: rgb(30, 36, 43);\n"
"")
        self.Table1Frame.setFrameShape(QFrame.StyledPanel)
        self.Table1Frame.setFrameShadow(QFrame.Raised)
        self.gridLayout = QGridLayout(self.Table1Frame)
        self.gridLayout.setObjectName(u"gridLayout")
        self.horizontalLayout = QHBoxLayout()
        self.horizontalLayout.setSpacing(45)
        self.horizontalLayout.setObjectName(u"horizontalLayout")
        self.horizontalLayout.setContentsMargins(6, -1, -1, 5)
        self.verticalLayout = QVBoxLayout()
        self.verticalLayout.setSpacing(8)
        self.verticalLayout.setObjectName(u"verticalLayout")
        self.verticalLayout.setContentsMargins(2, 2, 12, 0)
        self.verticalSpacer = QSpacerItem(20, 40, QSizePolicy.Minimum, QSizePolicy.Expanding)

        self.verticalLayout.addItem(self.verticalSpacer)

        self.label_2 = QLabel(self.Table1Frame)
        self.label_2.setObjectName(u"label_2")
        font = QFont()
        font.setFamilies([u"Arial"])
        font.setPointSize(12)
        font.setBold(False)
        font.setItalic(False)
        self.label_2.setFont(font)
        self.label_2.setStyleSheet(u"font: 12pt \"Arial\";\n"
"color: rgb(113, 113, 113)")

        self.verticalLayout.addWidget(self.label_2)

        self.StatusLable1 = QLabel(self.Table1Frame)
        self.StatusLable1.setObjectName(u"StatusLable1")
        self.StatusLable1.setFont(font)
        self.StatusLable1.setStyleSheet(u"font: 12pt \"Arial\";\n"
"color: rgb(113, 113, 113)")

        self.verticalLayout.addWidget(self.StatusLable1)

        self.Button1 = QPushButton(self.Table1Frame)
        self.Button1.setObjectName(u"Button1")
        self.Button1.setMinimumSize(QSize(141, 31))
        self.Button1.setStyleSheet(u"QPushButton {\n"
"background-color:rgb(0, 218, 160);\n"
"border-style: outset; \n"
"border-radius: 15px; \n"
"border-color: rgb(0, 255, 191);\n"
"font: 700 14pt \"Arial\";\n"
"color: rgb(255, 255, 255);\n"
"padding: 4px; \n"
"}\n"
"\n"
"QPushButton:hover {\n"
"	background-color: rgb(0, 239, 175);\n"
"}\n"
"\n"
"QPushButton:pressed {\n"
"	background-color: rgb(0, 255, 187);\n"
"}")

        self.verticalLayout.addWidget(self.Button1)


        self.horizontalLayout.addLayout(self.verticalLayout)

        self.label_4 = QLabel(self.Table1Frame)
        self.label_4.setObjectName(u"label_4")
        self.label_4.setMinimumSize(QSize(61, 108))
        self.label_4.setStyleSheet(u"color: rgb(255, 255, 255);\n"
"font: 700 110pt \"Arial\";")
        self.label_4.setIndent(-1)

        self.horizontalLayout.addWidget(self.label_4)


        self.gridLayout.addLayout(self.horizontalLayout, 0, 0, 1, 1)


        self.gridLayout_9.addWidget(self.Table1Frame, 1, 0, 1, 1)

        self.Table2Frame = QFrame(self.widget)
        self.Table2Frame.setObjectName(u"Table2Frame")
        self.Table2Frame.setMinimumSize(QSize(312, 216))
        self.Table2Frame.setStyleSheet(u"background-color: rgb(30, 36, 43);\n"
"border-style: outset; \n"
"border-radius: 15px; \n"
"border-color: rgb(0, 255, 191);\n"
"font: 700 14pt \"Arial\";\n"
"color: rgb(30, 36, 43);\n"
"")
        self.Table2Frame.setFrameShape(QFrame.StyledPanel)
        self.Table2Frame.setFrameShadow(QFrame.Raised)
        self.gridLayout_2 = QGridLayout(self.Table2Frame)
        self.gridLayout_2.setObjectName(u"gridLayout_2")
        self.horizontalLayout_2 = QHBoxLayout()
        self.horizontalLayout_2.setSpacing(45)
        self.horizontalLayout_2.setObjectName(u"horizontalLayout_2")
        self.horizontalLayout_2.setContentsMargins(6, -1, -1, 5)
        self.verticalLayout_4 = QVBoxLayout()
        self.verticalLayout_4.setSpacing(8)
        self.verticalLayout_4.setObjectName(u"verticalLayout_4")
        self.verticalLayout_4.setContentsMargins(2, 2, 12, 0)
        self.verticalSpacer_4 = QSpacerItem(20, 40, QSizePolicy.Minimum, QSizePolicy.Expanding)

        self.verticalLayout_4.addItem(self.verticalSpacer_4)

        self.lable = QLabel(self.Table2Frame)
        self.lable.setObjectName(u"lable")
        self.lable.setFont(font)
        self.lable.setStyleSheet(u"font: 12pt \"Arial\";\n"
"color: rgb(113, 113, 113)")

        self.verticalLayout_4.addWidget(self.lable)

        self.StatusLable2 = QLabel(self.Table2Frame)
        self.StatusLable2.setObjectName(u"StatusLable2")
        self.StatusLable2.setFont(font)
        self.StatusLable2.setStyleSheet(u"font: 12pt \"Arial\";\n"
"color: rgb(113, 113, 113)")

        self.verticalLayout_4.addWidget(self.StatusLable2)

        self.Button2 = QPushButton(self.Table2Frame)
        self.Button2.setObjectName(u"Button2")
        self.Button2.setMinimumSize(QSize(141, 31))
        self.Button2.setStyleSheet(u"QPushButton{\n"
"background-color: rgb(0, 218, 160);\n"
"border-style: outset; \n"
"border-radius: 15px; \n"
"border-color: rgb(0, 255, 191);\n"
"font: 700 14pt \"Arial\";\n"
"color: rgb(255, 255, 255);\n"
"padding: 4px; \n"
"}\n"
"\n"
"QPushButton:hover {\n"
"	background-color: rgb(0, 239, 175);\n"
"}\n"
"\n"
"QPushButton:pressed {\n"
"	background-color: rgb(0, 255, 187);\n"
"}\n"
"")

        self.verticalLayout_4.addWidget(self.Button2)


        self.horizontalLayout_2.addLayout(self.verticalLayout_4)

        self.label_16 = QLabel(self.Table2Frame)
        self.label_16.setObjectName(u"label_16")
        self.label_16.setMinimumSize(QSize(61, 108))
        self.label_16.setStyleSheet(u"color: rgb(255, 255, 255);\n"
"font: 700 110pt \"Arial\";")
        self.label_16.setIndent(-1)

        self.horizontalLayout_2.addWidget(self.label_16)


        self.gridLayout_2.addLayout(self.horizontalLayout_2, 0, 0, 1, 1)


        self.gridLayout_9.addWidget(self.Table2Frame, 1, 1, 1, 1)

        self.Table3Frame = QFrame(self.widget)
        self.Table3Frame.setObjectName(u"Table3Frame")
        self.Table3Frame.setMinimumSize(QSize(312, 216))
        self.Table3Frame.setStyleSheet(u"background-color: rgb(30, 36, 43);\n"
"border-style: outset; \n"
"border-radius: 15px; \n"
"border-color: rgb(0, 255, 191);\n"
"font: 700 14pt \"Arial\";\n"
"color: rgb(30, 36, 43);\n"
"")
        self.Table3Frame.setFrameShape(QFrame.StyledPanel)
        self.Table3Frame.setFrameShadow(QFrame.Raised)
        self.gridLayout_7 = QGridLayout(self.Table3Frame)
        self.gridLayout_7.setObjectName(u"gridLayout_7")
        self.horizontalLayout_7 = QHBoxLayout()
        self.horizontalLayout_7.setSpacing(45)
        self.horizontalLayout_7.setObjectName(u"horizontalLayout_7")
        self.horizontalLayout_7.setContentsMargins(6, -1, -1, 5)
        self.verticalLayout_5 = QVBoxLayout()
        self.verticalLayout_5.setSpacing(8)
        self.verticalLayout_5.setObjectName(u"verticalLayout_5")
        self.verticalLayout_5.setContentsMargins(2, 2, 12, 0)
        self.verticalSpacer_5 = QSpacerItem(20, 40, QSizePolicy.Minimum, QSizePolicy.Expanding)

        self.verticalLayout_5.addItem(self.verticalSpacer_5)

        self.label_17 = QLabel(self.Table3Frame)
        self.label_17.setObjectName(u"label_17")
        self.label_17.setFont(font)
        self.label_17.setStyleSheet(u"font: 12pt \"Arial\";\n"
"color: rgb(113, 113, 113)")

        self.verticalLayout_5.addWidget(self.label_17)

        self.StatusLable3 = QLabel(self.Table3Frame)
        self.StatusLable3.setObjectName(u"StatusLable3")
        self.StatusLable3.setFont(font)
        self.StatusLable3.setStyleSheet(u"font: 12pt \"Arial\";\n"
"color: rgb(113, 113, 113)")

        self.verticalLayout_5.addWidget(self.StatusLable3)

        self.Button3 = QPushButton(self.Table3Frame)
        self.Button3.setObjectName(u"Button3")
        self.Button3.setMinimumSize(QSize(141, 31))
        self.Button3.setStyleSheet(u"QPushButton{\n"
"background-color:rgb(0, 218, 160);\n"
"border-style: outset; \n"
"border-radius: 15px; \n"
"border-color: rgb(0, 255, 191);\n"
"font: 700 14pt \"Arial\";\n"
"color: rgb(255, 255, 255);\n"
"padding: 4px; \n"
"}\n"
"\n"
"QPushButton:hover {\n"
"	background-color: rgb(0, 239, 175);\n"
"}\n"
"\n"
"QPushButton:pressed {\n"
"	background-color: rgb(0, 255, 187);\n"
"}")

        self.verticalLayout_5.addWidget(self.Button3)


        self.horizontalLayout_7.addLayout(self.verticalLayout_5)

        self.label_19 = QLabel(self.Table3Frame)
        self.label_19.setObjectName(u"label_19")
        self.label_19.setMinimumSize(QSize(61, 108))
        self.label_19.setStyleSheet(u"color: rgb(255, 255, 255);\n"
"font: 700 110pt \"Arial\";")
        self.label_19.setIndent(-1)

        self.horizontalLayout_7.addWidget(self.label_19)


        self.gridLayout_7.addLayout(self.horizontalLayout_7, 0, 0, 1, 1)


        self.gridLayout_9.addWidget(self.Table3Frame, 2, 0, 1, 1)

        self.Table4Frame = QFrame(self.widget)
        self.Table4Frame.setObjectName(u"Table4Frame")
        self.Table4Frame.setMinimumSize(QSize(312, 216))
        self.Table4Frame.setStyleSheet(u"background-color: rgb(30, 36, 43);\n"
"border-style: outset; \n"
"border-radius: 15px; \n"
"border-color: rgb(0, 255, 191);\n"
"font: 700 14pt \"Arial\";\n"
"color: rgb(30, 36, 43);\n"
"")
        self.Table4Frame.setFrameShape(QFrame.StyledPanel)
        self.Table4Frame.setFrameShadow(QFrame.Raised)
        self.gridLayout_8 = QGridLayout(self.Table4Frame)
        self.gridLayout_8.setObjectName(u"gridLayout_8")
        self.horizontalLayout_8 = QHBoxLayout()
        self.horizontalLayout_8.setSpacing(45)
        self.horizontalLayout_8.setObjectName(u"horizontalLayout_8")
        self.horizontalLayout_8.setContentsMargins(6, -1, -1, 5)
        self.verticalLayout_6 = QVBoxLayout()
        self.verticalLayout_6.setSpacing(8)
        self.verticalLayout_6.setObjectName(u"verticalLayout_6")
        self.verticalLayout_6.setContentsMargins(2, 2, 12, 0)
        self.verticalSpacer_6 = QSpacerItem(20, 40, QSizePolicy.Minimum, QSizePolicy.Expanding)

        self.verticalLayout_6.addItem(self.verticalSpacer_6)

        self.label_20 = QLabel(self.Table4Frame)
        self.label_20.setObjectName(u"label_20")
        self.label_20.setFont(font)
        self.label_20.setStyleSheet(u"font: 12pt \"Arial\";\n"
"color: rgb(113, 113, 113)")

        self.verticalLayout_6.addWidget(self.label_20)

        self.StatusLable4 = QLabel(self.Table4Frame)
        self.StatusLable4.setObjectName(u"StatusLable4")
        self.StatusLable4.setFont(font)
        self.StatusLable4.setStyleSheet(u"font: 12pt \"Arial\";\n"
"color: rgb(113, 113, 113)")

        self.verticalLayout_6.addWidget(self.StatusLable4)

        self.pushButton_9 = QPushButton(self.Table4Frame)
        self.pushButton_9.setObjectName(u"pushButton_9")
        self.pushButton_9.setMinimumSize(QSize(141, 31))
        self.pushButton_9.setStyleSheet(u"QPushButton{\n"
"background-color: rgb(0, 218, 160);\n"
"border-style: outset; \n"
"border-radius: 15px; \n"
"border-color: rgb(0, 255, 191);\n"
"font: 700 14pt \"Arial\";\n"
"color: rgb(255, 255, 255);\n"
"padding: 4px; \n"
"}\n"
"\n"
"QPushButton:hover {\n"
"	background-color: rgb(0, 239, 175);\n"
"}\n"
"\n"
"QPushButton:pressed {\n"
"	background-color: rgb(0, 255, 187);\n"
"}\n"
"")

        self.verticalLayout_6.addWidget(self.pushButton_9)


        self.horizontalLayout_8.addLayout(self.verticalLayout_6)

        self.label_22 = QLabel(self.Table4Frame)
        self.label_22.setObjectName(u"label_22")
        self.label_22.setMinimumSize(QSize(61, 108))
        self.label_22.setStyleSheet(u"color: rgb(255, 255, 255);\n"
"font: 700 110pt \"Arial\";")
        self.label_22.setIndent(-1)

        self.horizontalLayout_8.addWidget(self.label_22)


        self.gridLayout_8.addLayout(self.horizontalLayout_8, 0, 0, 1, 1)


        self.gridLayout_9.addWidget(self.Table4Frame, 2, 1, 1, 1)


        self.retranslateUi(Dialog)

        QMetaObject.connectSlotsByName(Dialog)
    # setupUi

    def retranslateUi(self, Dialog):
        Dialog.setWindowTitle(QCoreApplication.translate("Dialog", u"Dialog", None))
        self.label.setText(QCoreApplication.translate("Dialog", u"\u041f\u0440\u0438\u0432\u0435\u0442", None))
        self.HelloLable.setText("")
#if QT_CONFIG(tooltip)
        self.ProfilButton.setToolTip(QCoreApplication.translate("Dialog", u"<html><head/><body><p><br/></p></body></html>", None))
#endif // QT_CONFIG(tooltip)
#if QT_CONFIG(whatsthis)
        self.ProfilButton.setWhatsThis(QCoreApplication.translate("Dialog", u"<html><head/><body><p>\u041f\u0440\u043e\u0444\u0438\u043b\u044c</p></body></html>", None))
#endif // QT_CONFIG(whatsthis)
        self.ProfilButton.setText("")
        self.QuestionButton.setText("")
        self.InfoButton.setText("")
#if QT_CONFIG(whatsthis)
        self.label_2.setWhatsThis(QCoreApplication.translate("Dialog", u"<html><head/><body><p>\u0421\u0442\u0430\u0442\u0443\u0441 \u0441\u0442\u043e\u043b\u0430:</p><p>1. \u0421\u0432\u043e\u0431\u043e\u0434\u0435\u043d - \u0437\u0430 \u0441\u0442\u043e\u043b\u043e\u043c \u043d\u0438\u043a\u043e\u0433\u043e \u043d\u0435\u0442</p><p>2. \u041e\u0436\u0438\u0434\u0430\u0435\u0442 - \u0437\u0430 \u0441\u0442\u043e\u043b\u043e\u043c \u0433\u043e\u0441\u0442\u0438, \u043c\u043e\u0436\u043d\u043e \u0435\u0433\u043e \u043f\u0440\u0438\u043d\u044f\u0442\u044c</p><p>3. \u041d\u0435 \u0440\u0430\u0441\u0441\u0447\u0438\u0442\u0430\u043d - \u0437\u0430\u043a\u0430\u0437 \u0431\u044b\u043b \u0441\u0434\u0435\u043b\u0430\u043d, \u043c\u043e\u0436\u043d\u043e \u0440\u0430\u0441\u0441\u0447\u0438\u0442\u0430\u0442\u044c \u0441\u0442\u043e\u043b</p></body></html>", None))
#endif // QT_CONFIG(whatsthis)
        self.label_2.setText(QCoreApplication.translate("Dialog", u"\u0421\u0442\u0430\u0442\u0443\u0441:", None))
        self.StatusLable1.setText("")
#if QT_CONFIG(whatsthis)
        self.Button1.setWhatsThis(QCoreApplication.translate("Dialog", u"<html><head/><body><p>\u041d\u0430\u0436\u043c\u0438, \u0447\u0442\u043e\u0431\u044b \u043f\u0440\u0438\u043d\u044f\u0442\u044c \u0441\u0442\u043e\u043b.</p></body></html>", None))
#endif // QT_CONFIG(whatsthis)
        self.Button1.setText(QCoreApplication.translate("Dialog", u"\u041f\u0440\u0438\u043d\u044f\u0442\u044c!", None))
        self.label_4.setText(QCoreApplication.translate("Dialog", u"1", None))
#if QT_CONFIG(whatsthis)
        self.lable.setWhatsThis(QCoreApplication.translate("Dialog", u"<html><head/><body><p>\u0421\u0442\u0430\u0442\u0443\u0441 \u0441\u0442\u043e\u043b\u0430:</p><p>1. \u0421\u0432\u043e\u0431\u043e\u0434\u0435\u043d - \u0437\u0430 \u0441\u0442\u043e\u043b\u043e\u043c \u043d\u0438\u043a\u043e\u0433\u043e \u043d\u0435\u0442</p><p>2. \u041e\u0436\u0438\u0434\u0430\u0435\u0442 - \u0437\u0430 \u0441\u0442\u043e\u043b\u043e\u043c \u0433\u043e\u0441\u0442\u0438, \u043c\u043e\u0436\u043d\u043e \u0435\u0433\u043e \u043f\u0440\u0438\u043d\u044f\u0442\u044c</p><p>3. \u041d\u0435 \u0440\u0430\u0441\u0441\u0447\u0438\u0442\u0430\u043d - \u0437\u0430\u043a\u0430\u0437 \u0431\u044b\u043b \u0441\u0434\u0435\u043b\u0430\u043d, \u043c\u043e\u0436\u043d\u043e \u0440\u0430\u0441\u0441\u0447\u0438\u0442\u0430\u0442\u044c \u0441\u0442\u043e\u043b</p></body></html>", None))
#endif // QT_CONFIG(whatsthis)
        self.lable.setText(QCoreApplication.translate("Dialog", u"\u0421\u0442\u0430\u0442\u0443\u0441:", None))
        self.StatusLable2.setText("")
#if QT_CONFIG(whatsthis)
        self.Button2.setWhatsThis(QCoreApplication.translate("Dialog", u"<html><head/><body><p>\u041d\u0430\u0436\u043c\u0438, \u0447\u0442\u043e\u0431\u044b \u043f\u0440\u0438\u043d\u044f\u0442\u044c \u0441\u0442\u043e\u043b.</p></body></html>", None))
#endif // QT_CONFIG(whatsthis)
        self.Button2.setText(QCoreApplication.translate("Dialog", u"\u041f\u0440\u0438\u043d\u044f\u0442\u044c!", None))
        self.label_16.setText(QCoreApplication.translate("Dialog", u"2", None))
#if QT_CONFIG(whatsthis)
        self.label_17.setWhatsThis(QCoreApplication.translate("Dialog", u"<html><head/><body><p>\u0421\u0442\u0430\u0442\u0443\u0441 \u0441\u0442\u043e\u043b\u0430:</p><p>1. \u0421\u0432\u043e\u0431\u043e\u0434\u0435\u043d - \u0437\u0430 \u0441\u0442\u043e\u043b\u043e\u043c \u043d\u0438\u043a\u043e\u0433\u043e \u043d\u0435\u0442</p><p>2. \u041e\u0436\u0438\u0434\u0430\u0435\u0442 - \u0437\u0430 \u0441\u0442\u043e\u043b\u043e\u043c \u0433\u043e\u0441\u0442\u0438, \u043c\u043e\u0436\u043d\u043e \u0435\u0433\u043e \u043f\u0440\u0438\u043d\u044f\u0442\u044c</p><p>3. \u041d\u0435 \u0440\u0430\u0441\u0441\u0447\u0438\u0442\u0430\u043d - \u0437\u0430\u043a\u0430\u0437 \u0431\u044b\u043b \u0441\u0434\u0435\u043b\u0430\u043d, \u043c\u043e\u0436\u043d\u043e \u0440\u0430\u0441\u0441\u0447\u0438\u0442\u0430\u0442\u044c \u0441\u0442\u043e\u043b</p></body></html>", None))
#endif // QT_CONFIG(whatsthis)
        self.label_17.setText(QCoreApplication.translate("Dialog", u"\u0421\u0442\u0430\u0442\u0443\u0441:", None))
        self.StatusLable3.setText("")
#if QT_CONFIG(whatsthis)
        self.Button3.setWhatsThis(QCoreApplication.translate("Dialog", u"<html><head/><body><p>\u041d\u0430\u0436\u043c\u0438, \u0447\u0442\u043e\u0431\u044b \u043f\u0440\u0438\u043d\u044f\u0442\u044c \u0441\u0442\u043e\u043b.</p></body></html>", None))
#endif // QT_CONFIG(whatsthis)
        self.Button3.setText(QCoreApplication.translate("Dialog", u"\u041f\u0440\u0438\u043d\u044f\u0442\u044c!", None))
        self.label_19.setText(QCoreApplication.translate("Dialog", u"3", None))
#if QT_CONFIG(whatsthis)
        self.label_20.setWhatsThis(QCoreApplication.translate("Dialog", u"<html><head/><body><p>\u0421\u0442\u0430\u0442\u0443\u0441 \u0441\u0442\u043e\u043b\u0430:</p><p>1. \u0421\u0432\u043e\u0431\u043e\u0434\u0435\u043d - \u0437\u0430 \u0441\u0442\u043e\u043b\u043e\u043c \u043d\u0438\u043a\u043e\u0433\u043e \u043d\u0435\u0442</p><p>2. \u041e\u0436\u0438\u0434\u0430\u0435\u0442 - \u0437\u0430 \u0441\u0442\u043e\u043b\u043e\u043c \u0433\u043e\u0441\u0442\u0438, \u043c\u043e\u0436\u043d\u043e \u0435\u0433\u043e \u043f\u0440\u0438\u043d\u044f\u0442\u044c</p><p>3. \u041d\u0435 \u0440\u0430\u0441\u0441\u0447\u0438\u0442\u0430\u043d - \u0437\u0430\u043a\u0430\u0437 \u0431\u044b\u043b \u0441\u0434\u0435\u043b\u0430\u043d, \u043c\u043e\u0436\u043d\u043e \u0440\u0430\u0441\u0441\u0447\u0438\u0442\u0430\u0442\u044c \u0441\u0442\u043e\u043b</p></body></html>", None))
#endif // QT_CONFIG(whatsthis)
        self.label_20.setText(QCoreApplication.translate("Dialog", u"\u0421\u0442\u0430\u0442\u0443\u0441:", None))
        self.StatusLable4.setText("")
#if QT_CONFIG(whatsthis)
        self.pushButton_9.setWhatsThis(QCoreApplication.translate("Dialog", u"<html><head/><body><p>\u041d\u0430\u0436\u043c\u0438, \u0447\u0442\u043e\u0431\u044b \u043f\u0440\u0438\u043d\u044f\u0442\u044c \u0441\u0442\u043e\u043b.</p></body></html>", None))
#endif // QT_CONFIG(whatsthis)
        self.pushButton_9.setText(QCoreApplication.translate("Dialog", u"\u041f\u0440\u0438\u043d\u044f\u0442\u044c!", None))
        self.label_22.setText(QCoreApplication.translate("Dialog", u"4", None))
    # retranslateUi

