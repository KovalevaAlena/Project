# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'windowEntrance.ui'
##
## Created by: Qt User Interface Compiler version 6.6.0
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide6.QtCore import (QCoreApplication, QDate, QDateTime, QLocale,
    QMetaObject, QObject, QPoint, QRect,
    QSize, QTime, QUrl, Qt)
from PySide6.QtGui import (QBrush, QColor, QConicalGradient, QCursor,
    QFont, QFontDatabase, QGradient, QIcon,
    QImage, QKeySequence, QLinearGradient, QPainter,
    QPalette, QPixmap, QRadialGradient, QTransform)
from PySide6.QtWidgets import (QApplication, QFormLayout, QLabel, QLineEdit,
    QMainWindow, QPushButton, QSizePolicy, QSpacerItem,
    QVBoxLayout, QWidget)

class Ui_MainWindow(object):
    def setupUi(self, MainWindow):
        if not MainWindow.objectName():
            MainWindow.setObjectName(u"MainWindow")
        MainWindow.resize(364, 403)
        MainWindow.setStyleSheet(u"background-color: rgb(18, 25, 27);")
        self.centralwidget = QWidget(MainWindow)
        self.centralwidget.setObjectName(u"centralwidget")
        self.verticalLayout = QVBoxLayout(self.centralwidget)
        self.verticalLayout.setObjectName(u"verticalLayout")
        self.verticalSpacer_2 = QSpacerItem(20, 40, QSizePolicy.Minimum, QSizePolicy.Expanding)

        self.verticalLayout.addItem(self.verticalSpacer_2)

        self.EntranceLable = QLabel(self.centralwidget)
        self.EntranceLable.setObjectName(u"EntranceLable")
        self.EntranceLable.setEnabled(True)
        self.EntranceLable.setMaximumSize(QSize(321, 50))
        self.EntranceLable.setToolTipDuration(-1)
        self.EntranceLable.setLayoutDirection(Qt.LeftToRight)
        self.EntranceLable.setStyleSheet(u"color: rgb(255, 255, 255);\n"
"font: 700 22pt \"Arial\";")
        self.EntranceLable.setLineWidth(1)
        self.EntranceLable.setIndent(135)

        self.verticalLayout.addWidget(self.EntranceLable)

        self.verticalSpacer = QSpacerItem(20, 10, QSizePolicy.Minimum, QSizePolicy.Expanding)

        self.verticalLayout.addItem(self.verticalSpacer)

        self.formLayout = QFormLayout()
        self.formLayout.setObjectName(u"formLayout")
        self.formLayout.setHorizontalSpacing(6)
        self.formLayout.setVerticalSpacing(10)
        self.LoginLable = QLabel(self.centralwidget)
        self.LoginLable.setObjectName(u"LoginLable")
        self.LoginLable.setStyleSheet(u"color: rgb(255, 255, 255);\n"
"font: 700 14pt \"Arial\";")

        self.formLayout.setWidget(0, QFormLayout.LabelRole, self.LoginLable)

        self.LoginEdit = QLineEdit(self.centralwidget)
        self.LoginEdit.setObjectName(u"LoginEdit")
        self.LoginEdit.setStyleSheet(u"\n"
"	background-color: rgba(255, 255, 255, 70);\n"
"	border:rgb(0, 170, 127);\n"
"	border-style: outset; \n"
"	border-width: 1px; \n"
"	border-radius: 15px; \n"
"	border-color: white; \n"
"	color: rgb(255, 255, 255);\n"
"	font: 12pt \"Arial\";\n"
"")

        self.formLayout.setWidget(0, QFormLayout.FieldRole, self.LoginEdit)

        self.PasswordLable = QLabel(self.centralwidget)
        self.PasswordLable.setObjectName(u"PasswordLable")
        self.PasswordLable.setStyleSheet(u"color: rgb(255, 255, 255);\n"
"font: 700 14pt \"Arial\";")

        self.formLayout.setWidget(1, QFormLayout.LabelRole, self.PasswordLable)

        self.PasswordEdit = QLineEdit(self.centralwidget)
        self.PasswordEdit.setObjectName(u"PasswordEdit")
        self.PasswordEdit.setStyleSheet(u"\n"
"	background-color: rgba(255, 255, 255, 70);\n"
"	border:rgb(0, 170, 127);\n"
"	border-style: outset; \n"
"	border-width: 1px; \n"
"	border-radius: 15px; \n"
"	border-color: white; \n"
"	color: rgb(255, 255, 255);\n"
"	font: 12pt \"Arial\";\n"
"")

        self.formLayout.setWidget(1, QFormLayout.FieldRole, self.PasswordEdit)


        self.verticalLayout.addLayout(self.formLayout)

        self.EntranceButton = QPushButton(self.centralwidget)
        self.EntranceButton.setObjectName(u"EntranceButton")
        self.EntranceButton.setMouseTracking(True)
        self.EntranceButton.setTabletTracking(False)
        self.EntranceButton.setStyleSheet(u"QPushButton{\n"
"background-color: rgb(0, 218, 160);\n"
"border-style: outset; \n"
"border-width: 2px; \n"
"border-radius: 15px; \n"
"border-color: rgb(0, 255, 191);\n"
"font: 700 14pt \"Arial\";\n"
"padding: 4px; \n"
"color: rgb(255, 255, 255);\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"	background-color: rgb(0, 239, 175);\n"
"}\n"
"\n"
"QPushButton:pressed {\n"
"	background-color: rgb(0, 255, 187);\n"
"}")

        self.verticalLayout.addWidget(self.EntranceButton)

        self.verticalSpacer_3 = QSpacerItem(20, 40, QSizePolicy.Minimum, QSizePolicy.Expanding)

        self.verticalLayout.addItem(self.verticalSpacer_3)

        MainWindow.setCentralWidget(self.centralwidget)
        self.EntranceLable.raise_()
        self.EntranceButton.raise_()

        self.retranslateUi(MainWindow)

        QMetaObject.connectSlotsByName(MainWindow)
    # setupUi

    def retranslateUi(self, MainWindow):
        MainWindow.setWindowTitle(QCoreApplication.translate("MainWindow", u"\u0412\u0445\u043e\u0434", None))
        self.EntranceLable.setText(QCoreApplication.translate("MainWindow", u"\u0412\u0445\u043e\u0434", None))
        self.LoginLable.setText(QCoreApplication.translate("MainWindow", u"\u041b\u043e\u0433\u0438\u043d:", None))
#if QT_CONFIG(tooltip)
        self.LoginEdit.setToolTip(QCoreApplication.translate("MainWindow", u"<html><head/><body><p><span style=\" font-size:16pt;\">dsddsdsdd</span></p></body></html>", None))
#endif // QT_CONFIG(tooltip)
#if QT_CONFIG(whatsthis)
        self.LoginEdit.setWhatsThis(QCoreApplication.translate("MainWindow", u"<html><head/><body><p>dddddddd</p></body></html>", None))
#endif // QT_CONFIG(whatsthis)
        self.PasswordLable.setText(QCoreApplication.translate("MainWindow", u"\u041f\u0430\u0440\u043e\u043b\u044c:", None))
        self.EntranceButton.setText(QCoreApplication.translate("MainWindow", u"\u0412\u043e\u0439\u0442\u0438", None))
    # retranslateUi

