import unittest
from PyQt5.QtWidgets import QApplication
from main import infowindow

class TestInfoWindow(unittest.TestCase):
    def setUp(self):
        self.app = QApplication([])

    def tearDown(self):
        self.app.quit()

    def test_ui_loading(self):
        info_wind = infowindow()
        self.assertIsNotNone(info_wind)



if __name__ == '__main__':
    unittest.main()