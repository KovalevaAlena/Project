# Resource object code (Python 3)
# Created by: object code
# Created by: The Resource Compiler for Qt version 6.6.0
# WARNING! All changes made in this file will be lost!

from PySide6 import QtCore

qt_resource_data = b"\
\x00\x00\x03$\
<\
svg version=\x221.1\
\x22 xmlns=\x22http://\
www.w3.org/2000/\
svg\x22 xmlns:xlink\
=\x22http://www.w3.\
org/1999/xlink\x22 \
width=\x2224\x22 heigh\
t=\x2224\x22 viewBox=\x22\
0,0,256,256\x22><g \
fill=\x22#ffffff\x22 f\
ill-rule=\x22nonzer\
o\x22 stroke=\x22none\x22\
 stroke-width=\x221\
\x22 stroke-linecap\
=\x22butt\x22 stroke-l\
inejoin=\x22miter\x22 \
stroke-miterlimi\
t=\x2210\x22 stroke-da\
sharray=\x22\x22 strok\
e-dashoffset=\x220\x22\
 font-family=\x22no\
ne\x22 font-weight=\
\x22none\x22 font-size\
=\x22none\x22 text-anc\
hor=\x22none\x22 style\
=\x22mix-blend-mode\
: normal\x22><g tra\
nsform=\x22translat\
e(0,256) scale(0\
.26667,0.26667)\x22\
><path d=\x22M280,-\
120c-22,0 -40.83\
333,-7.83333 -56\
.5,-23.5c-15.666\
67,-15.66667 -23\
.5,-34.5 -23.5,-\
56.5v-520h-40v-8\
0h200v-40h240v40\
h200v80h-40v520c\
0,22 -7.83333,40\
.83333 -23.5,56.\
5c-15.66667,15.6\
6667 -34.5,23.5 \
-56.5,23.5zM680,\
-720h-400v520h40\
0zM360,-280h80v-\
360h-80zM520,-28\
0h80v-360h-80zM2\
80,-720v520z\x22></\
path></g></g></s\
vg>\
\x00\x00\x06\xd2\
<\
svg version=\x221.1\
\x22 xmlns=\x22http://\
www.w3.org/2000/\
svg\x22 xmlns:xlink\
=\x22http://www.w3.\
org/1999/xlink\x22 \
width=\x2224\x22 heigh\
t=\x2224\x22 viewBox=\x22\
0,0,256,256\x22><g \
fill=\x22#ffffff\x22 f\
ill-rule=\x22nonzer\
o\x22 stroke=\x22none\x22\
 stroke-width=\x221\
\x22 stroke-linecap\
=\x22butt\x22 stroke-l\
inejoin=\x22miter\x22 \
stroke-miterlimi\
t=\x2210\x22 stroke-da\
sharray=\x22\x22 strok\
e-dashoffset=\x220\x22\
 font-family=\x22no\
ne\x22 font-weight=\
\x22none\x22 font-size\
=\x22none\x22 text-anc\
hor=\x22none\x22 style\
=\x22mix-blend-mode\
: normal\x22><g tra\
nsform=\x22translat\
e(0,256) scale(0\
.26667,0.26667)\x22\
><path d=\x22M480,-\
480c-44,0 -81.66\
667,-15.66667 -1\
13,-47c-31.33333\
,-31.33333 -47,-\
69 -47,-113c0,-4\
4 15.66667,-81.6\
6667 47,-113c31.\
33333,-31.33333 \
69,-47 113,-47c4\
4,0 81.66667,15.\
66667 113,47c31.\
33333,31.33333 4\
7,69 47,113c0,44\
 -15.66667,81.66\
667 -47,113c-31.\
33333,31.33333 -\
69,47 -113,47zM1\
60,-160v-112c0,-\
22.66667 5.83333\
,-43.5 17.5,-62.\
5c11.66667,-19 2\
7.16667,-33.5 46\
.5,-43.5c41.3333\
3,-20.66667 83.3\
3333,-36.16667 1\
26,-46.5c42.6666\
7,-10.33333 86,-\
15.5 130,-15.5c4\
4,0 87.33333,5.1\
6667 130,15.5c42\
.66667,10.33333 \
84.66667,25.8333\
3 126,46.5c19.33\
333,10 34.83333,\
24.5 46.5,43.5c1\
1.66667,19 17.5,\
39.83333 17.5,62\
.5v112zM240,-240\
h480v-32c0,-7.33\
333 -1.83333,-14\
 -5.5,-20c-3.666\
67,-6 -8.5,-10.6\
6667 -14.5,-14c-\
36,-18 -72.33333\
,-31.5 -109,-40.\
5c-36.66667,-9 -\
73.66667,-13.5 -\
111,-13.5c-37.33\
333,0 -74.33333,\
4.5 -111,13.5c-3\
6.66667,9 -73,22\
.5 -109,40.5c-6,\
3.33333 -10.8333\
3,8 -14.5,14c-3.\
66667,6 -5.5,12.\
66667 -5.5,20zM4\
80,-560c22,0 40.\
83333,-7.83333 5\
6.5,-23.5c15.666\
67,-15.66667 23.\
5,-34.5 23.5,-56\
.5c0,-22 -7.8333\
3,-40.83333 -23.\
5,-56.5c-15.6666\
7,-15.66667 -34.\
5,-23.5 -56.5,-2\
3.5c-22,0 -40.83\
333,7.83333 -56.\
5,23.5c-15.66667\
,15.66667 -23.5,\
34.5 -23.5,56.5c\
0,22 7.83333,40.\
83333 23.5,56.5c\
15.66667,15.6666\
7 34.5,23.5 56.5\
,23.5zM480,-640z\
M480,-240z\x22></pa\
th></g></g></svg\
>\
\x00\x00\x029\
<\
svg version=\x221.1\
\x22 xmlns=\x22http://\
www.w3.org/2000/\
svg\x22 xmlns:xlink\
=\x22http://www.w3.\
org/1999/xlink\x22 \
width=\x2224\x22 heigh\
t=\x2224\x22 viewBox=\x22\
0,0,256,256\x22><g \
fill=\x22#ffffff\x22 f\
ill-rule=\x22nonzer\
o\x22 stroke=\x22none\x22\
 stroke-width=\x221\
\x22 stroke-linecap\
=\x22butt\x22 stroke-l\
inejoin=\x22miter\x22 \
stroke-miterlimi\
t=\x2210\x22 stroke-da\
sharray=\x22\x22 strok\
e-dashoffset=\x220\x22\
 font-family=\x22no\
ne\x22 font-weight=\
\x22none\x22 font-size\
=\x22none\x22 text-anc\
hor=\x22none\x22 style\
=\x22mix-blend-mode\
: normal\x22><g tra\
nsform=\x22translat\
e(0,256) scale(0\
.26667,0.26667)\x22\
><path d=\x22M440,-\
440h-240v-80h240\
v-240h80v240h240\
v80h-240v240h-80\
z\x22></path></g></\
g></svg>\
"

qt_resource_name = b"\
\x00\x06\
\x06\xfaec\
\x00i\
\x00c\x00o\x00n\x00s\x003\
\x00\x05\
\x00o\xa6S\
\x00i\
\x00c\x00o\x00n\x00s\
\x00\x0a\
\x0c\xad\x02\x87\
\x00d\
\x00e\x00l\x00e\x00t\x00e\x00.\x00s\x00v\x00g\
\x00\x0a\
\x0ao\x83\xe7\
\x00p\
\x00e\x00r\x00s\x00o\x00n\x00.\x00s\x00v\x00g\
\x00\x07\
\x07\xa7Z\x07\
\x00a\
\x00d\x00d\x00.\x00s\x00v\x00g\
"

qt_resource_struct = b"\
\x00\x00\x00\x00\x00\x02\x00\x00\x00\x01\x00\x00\x00\x01\
\x00\x00\x00\x00\x00\x00\x00\x00\
\x00\x00\x00\x00\x00\x02\x00\x00\x00\x01\x00\x00\x00\x02\
\x00\x00\x00\x00\x00\x00\x00\x00\
\x00\x00\x00\x12\x00\x02\x00\x00\x00\x03\x00\x00\x00\x03\
\x00\x00\x00\x00\x00\x00\x00\x00\
\x00\x00\x00V\x00\x00\x00\x00\x00\x01\x00\x00\x09\xfe\
\x00\x00\x01\x8b\xd9\x9c\xb1s\
\x00\x00\x00<\x00\x00\x00\x00\x00\x01\x00\x00\x03(\
\x00\x00\x01\x8b\xd9\x9cy\xb6\
\x00\x00\x00\x22\x00\x00\x00\x00\x00\x01\x00\x00\x00\x00\
\x00\x00\x01\x8b\xd9\x9c\xea\xf5\
"

def qInitResources():
    QtCore.qRegisterResourceData(0x03, qt_resource_struct, qt_resource_name, qt_resource_data)

def qCleanupResources():
    QtCore.qUnregisterResourceData(0x03, qt_resource_struct, qt_resource_name, qt_resource_data)

qInitResources()
