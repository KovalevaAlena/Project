import sys
from PyQt5.QtCore import Qt
from PyQt5.QtWidgets import QApplication, QMainWindow, QLineEdit, QTableView, QMessageBox, QTableWidgetItem
from PyQt5.QtGui import QStandardItemModel, QStandardItem
from PyQt5 import uic, QtWidgets
from PyQt5.QtWidgets import QDialog
import random
from PyQt5 import QtCore
import sqlite3
import os
from PyQt5.QtWidgets import QDialog, QTableView, QLineEdit, QPushButton
import sqlite3
from PyQt5 import uic, QtWidgets

'''Класс БД'''
class Database:
    def __init__(self, db_name):
        '''Функция инициализации атрибутов класса'''
        self.conn = sqlite3.connect(db_name)
        self.cursor = self.conn.cursor()

    def create_table(self, table_name, columns):
        '''Функция создания таблиц'''
        self.cursor.execute(f"CREATE TABLE IF NOT EXISTS {table_name} ({columns})")
        self.conn.commit()

    def insert_data(self, table_name, values,  data):
        '''Функция внесения данных в бд'''
        self.cursor.execute(f"INSERT INTO {table_name} ({values}) VALUES ({data})")
        self.conn.commit()

    '''Функция вывода таблицы'''
    def select_data(self, table_name):
        self.cursor.execute(f"SELECT * FROM {table_name}")
        return self.cursor.fetchall()

    '''Функция вывода данных по условию'''
    def select_two_table_where_data(self, table_name, table, value1, value2, value3):
        self.cursor.execute(f"SELECT {value1}, {value2} FROM {table_name} WHERE {table} = {value3}")
        return self.cursor.fetchall()

    '''Функция вывода данных по условию'''
    def select_one_table_where_data(self, table_name, table, value1, value2):
        self.cursor.execute(f"SELECT {value1} FROM {table_name} WHERE {table} = {value2}")
        return self.cursor.fetchall()

    '''Функция обновления данных'''
    def update_data_where(self, table_name, table1, table2, values):
        self.cursor.execute(f"UPDATE {table_name} SET {table1} = ? where {table2} = ?", values)
        self.conn.commit()

    '''Функция вывода данных'''
    def select_three_tables_data(self, value1, value2, value3, table_name):
        self.cursor.execute(f"SELECT {value1}, {value2}, {value3} FROM {table_name}")
        return self.cursor.fetchall()

    '''Функция удаления таблицы'''
    def drop_table(self, table_name):
        self.cursor.execute(f"DROP TABLE {table_name}")
        self.conn.commit()

    '''Функция удаления поля в таблице'''
    def drop_column(self, table_name, column):
        self.cursor.execute(f"ALTER TABLE {table_name} DROP {column}")
        self.conn.commit()

    '''Функция добавления поля в таблицу'''
    def add_column(self, table_name, column, type):
        self.cursor.execute(f"ALTER TABLE {table_name} add {column} {type}")
        self.conn.commit()

    '''Функция определения поля как внешнего ключа'''
    def foreign_key(self, table_name, column, table_name2, column2):
        self.cursor.execute(f"ALTER TABLE {table_name} ADD FOREIGN KEY ({column}) REFERENCES {table_name2}({column2})")
        self.conn.commit()

    '''Функция соединения таблиц для вывода'''
    def inner_join(self, table_name, table_name2, columns, value1, value2):
        self.cursor.execute(f"select {columns} from {table_name} inner join {table_name2} on {value1} = {value2}")
        self.conn.commit()

    '''Функция закрытия соединения с бд'''
    def close_connection(self):
        self.conn.close()

'''Класс окна входа в программу'''
class MainWindow(QMainWindow):
    '''Функция инициализации атрибутов класса'''
    def __init__(self):
        super().__init__()
        uic.loadUi('windowEntrance.ui', self)
        self.user_wind = window1(self)
        self.EntranceButton.clicked.connect(self.button_entrance)
        self.PasswordEdit.setEchoMode(QLineEdit.Password)
        self.db = Database('restoran.db')

        '''Создание бд'''
        self.db.create_table('menu', 'id integer primary key autoincrement, product_name varchar(50), category integer, kolvo integer, price decimal(16,2), foreign key (category) references categories (id)')
        self.db.create_table('categories', 'id integer primary key autoincrement, category varchar(50)')
        self.db.create_table('orders', 'id integer primary key autoincrement, summa decimal(16,2), data text, table_num integer, foreign key (table_num) references tables (id)')
        self.db.create_table('list_orders', 'id integer primary key autoincrement, id_order integer, summa decimal(16,2), data text, foreign key (id_order) references orders (id)')
        self.db.create_table('user', 'id integer primary key autoincrement, fm varchar(50), im varchar(50), login varchar(50), password varchar(50), role integer, user_status integer default 0')
        self.db.create_table('status', 'id integer primary key autoincrement, status varchar(50)')
        self.db.create_table('tables', 'id integer primary key autoincrement, id_status integer')


    '''Функция проверки пароля для входа'''

    def button_entrance(self):
        login = self.LoginEdit.text()
        password = self.PasswordEdit.text()

        # Проверка на пустые поля
        if not login or not password:
            QMessageBox.warning(self, 'Пустые поля', 'Пожалуйста, введите логин и пароль.')
            return

        self.db.update_data_where('user', 'user_status', 'user_status', (0, 1))
        data = self.db.select_three_tables_data('login', 'password', 'role', 'user')
        lst_users = {}

        for i in range(len(data)):
            lst = []
            lst.append(data[i][1])
            lst.append(data[i][2])
            lst_users[data[i][0]] = lst

        for us, details in lst_users.items():
            if login == us and password == details[0]:
                self.db.update_data_where('user', 'user_status', 'login', (1, us))
                self.open_window(details[1])
                return

        # Если логин или пароль неверны
        QMessageBox.warning(self, 'Ошибка входа', 'Неверный логин или пароль.')
        return  # Добавленный return для прекращения выполнения функции

    '''Функция проверки роли для входа'''

    def open_window(self, role):
        self.close()
        if role == 1:
            user_wind = window1(self)
            user_wind.exec_()
        else:
            admin_wind = adminwindow(self)
            admin_wind.exec_()


'''Класс пользовательского окна'''
class window1(QDialog):
    '''Функция инициализации атрибутов класса'''
    def __init__(self, parent=None):
        super().__init__(parent)
        uic.loadUi('window1.ui', self)
        self.Button1.clicked.connect(self.button1)
        self.Button2.clicked.connect(self.button2)
        self.Button3.clicked.connect(self.button3)
        self.Button4.clicked.connect(self.button4)
        self.ProfilButton.clicked.connect(self.button_profil)
        self.InfoButton.clicked.connect(self.button_info)
        self.db = Database('restoran.db')
        self.none_status()
        self.name()

    '''Функция вывода фамилии и имени пользователя'''
    def name(self):
        text = self.Hello()
        self.HelloLable.setText(text)

    '''Функция формирование строки с фамилией и именем пользователя'''
    def Hello(self):
        data = self.db.select_one_table_where_data('user', 'user_status', 'im', '1')
        if data == []:
            return
        return 'Привет' + ' ' + str(data[0][0]) + '!'

    '''Функция извлечения из бд статусов столов'''
    def status_lable(self):
        self.db.cursor.execute("""select status from tables inner join status on tables.id_status = status.id""")
        data = self.db.cursor.fetchall()
        self.lables(data)

    '''Функция определение столов со статусом ожидает'''
    def none_status(self):
        update = """update tables set id_status = ? where id_status = ?"""
        self.db.cursor.execute(update, (1, 2))
        self.db.conn.commit()
        self.status_lable()

    '''Функция изменения статусов столов'''
    def change_status(self):
        num = random.randint(1, 4)
        update = """update tables set id_status = ? where tables.id = ?"""
        self.db.cursor.execute(update, (2, num))
        self.db.conn.commit()
        self.status_lable()

    '''Вывод статусов'''
    def lables(self, dct):
        self.StatusLable1.setText(dct[0][0])
        self.StatusLable2.setText(dct[1][0])
        self.StatusLable3.setText(dct[2][0])
        self.StatusLable4.setText(dct[3][0])

    '''Функция открытия окна заказа'''
    def button_order(self):
        order_wind = OrderWindow(self)
        order_wind.exec_()

    '''Функция для кнопки стола 1'''
    def button1(self):
        self.but_none()
        self.db.cursor.execute('''update tables set click_status = 1 where id = 1''')
        self.db.conn.commit()
        self.button_order()

    '''Функция для кнопки стола 2'''
    def button2(self):
        self.but_none()
        self.db.cursor.execute('''update tables set click_status = 1 where id = 2''')
        self.db.conn.commit()
        self.button_order()

    '''Функция для кнопки стола 3'''
    def button3(self):
        self.but_none()
        self.db.cursor.execute('''update tables set click_status = 1 where id = 3''')
        self.db.conn.commit()
        self.button_order()

    '''Функция для кнопки стола 4'''
    def button4(self):
        self.but_none()
        self.db.cursor.execute('''update tables set click_status = 1 where id = 4''')
        self.db.conn.commit()
        self.button_order()

    '''Функция удаления статуса нажатия на столы'''
    def but_none(self):
        self.db.cursor.execute('''update tables set click_status = 0 where click_status = 1''')
        self.db.conn.commit()

    '''Функция открытия окна профиля'''
    def button_profil(self):
        profile_wind = ProfilWindow(self)
        profile_wind.exec_()

    '''Функция открытия окна о программе'''
    def button_info(self):
        info_wind = infowindow(self)
        info_wind.exec_()


'''Класс окна заказа'''
class OrderWindow(QtWidgets.QDialog):
    def __init__(self, parent=None):
        super(OrderWindow, self).__init__(parent)
        uic.loadUi('OrderWindow.ui', self)
        self.summ = 0

        # Инициализация базы данных SQLite
        self.conn = sqlite3.connect('restoran.db')
        self.cursor = self.conn.cursor()

        # Другие инициализации...
        self.w1 = window1(self)

        # Настройка MenuTable
        self.MenuTable.setSelectionMode(QTableView.SingleSelection)
        self.MenuTable.setSelectionBehavior(QTableView.SelectRows)
        self.MenuTable.clicked.connect(self.show_selected_record)

        # Создание и настройка модели для таблицы
        self.menu_model = QStandardItemModel(self)
        headers = ["Номер", "Продукт", "Категория", "Количество", "Цена"]
        self.menu_model.setHorizontalHeaderLabels(headers)
        self.MenuTable.setModel(self.menu_model)

        # Добавьте модель для OrderTable
        self.order_model = QStandardItemModel(self)
        self.order_model.setHorizontalHeaderLabels(["Название", "Цена"])
        self.OrderTable.setModel(self.order_model)

        # Загрузка данных в MenuTable
        self.load_menu_data()

        # Добавьте кнопки и их обработчики
        self.BuyButton.clicked.connect(self.button_buy)
        self.DeleteButton.clicked.connect(self.button_delete)

    def show_selected_record(self, index):
        row = index.row()
        product_id = self.menu_model.data(self.menu_model.index(row, 0))
        self.add_product_to_order(product_id)

    def add_product_to_order(self, product_id):
        query = "SELECT product_name, price FROM menu WHERE id = ?"
        self.cursor.execute(query, (product_id,))
        product_info = self.cursor.fetchone()

        if product_info:
            name, price = product_info
            self.order_model.appendRow([QStandardItem(name), QStandardItem(str(price))])
            self.summa1(product_id)

    def summa1(self, id):
        data = "SELECT price FROM menu WHERE id = ?"
        self.cursor.execute(data, (id))
        price = self.cursor.fetchall()
        price = int(price[0][0])
        self.summ += price
        self.ItogLable.setNum(self.summ)

    def load_menu_data(self):
        try:
            query = "SELECT id, product_name, category, price FROM menu"
            self.cursor.execute(query)
            menu_data = self.cursor.fetchall()

            # Очищаем текущую модель перед добавлением новых данных
            self.menu_model.clear()
            self.menu_model.setHorizontalHeaderLabels(["Номер", "Продукт", "Категория", "Цена"])

            for row_num, row_data in enumerate(menu_data):
                for col_num, col_data in enumerate(row_data):
                    item = QStandardItem(str(col_data))
                    self.menu_model.setItem(row_num, col_num, item)

        except Exception as e:
            print(f"An error occurred: {e}")

    def button_delete(self):
        selected_rows = self.OrderTable.selectionModel().selectedRows()
        for row in reversed(selected_rows):
            self.summ -= float(self.order_model.item(row.row(), 1).text())
            self.order_model.removeRow(row.row())

        self.ItogLable.setNum(self.summ)

    def button_buy(self):
        try:
            # Добавление данных в таблицу orders
            self.add_order_to_database()
            self.close()
        except Exception as e:
            print(f"An error occurred during button_buy: {e}")
            raise  # Reraise the exception to see more details in the console



    def add_order_to_database(self):
        # Получение текущей даты
        current_date = QtCore.QDate.currentDate().toString(QtCore.Qt.ISODate)

        table_num = self.num_table()

        # Вставка данных в таблицу orders
        insert_order_query = "INSERT INTO orders (summa, data) VALUES (?, ?)"
        self.cursor.execute(insert_order_query, (self.summ, current_date))
        self.conn.commit()

        # Получение id только что вставленного заказа
        order_id = self.cursor.lastrowid

        # Вставка данных в таблицу list_orders


        insert_list_order_query = "INSERT INTO list_orders (id_order, summa, data) VALUES (?, ?, ?)"
        self.cursor.execute(insert_list_order_query, (order_id, self.summ, current_date))
        self.conn.commit()


    def num_table(self):
        self.cursor.execute('''select id from tables where click_status = 1''')
        data = self.cursor.fetchall()
        return data[0][0]





'''Класс окна профиля'''
class ProfilWindow(QDialog):
    '''Функция инициализации атрибутов класса'''
    def __init__(self, parent=None):
        super().__init__(parent)
        uic.loadUi('ProfilWindow.ui', self)
        self.exitButton.clicked.connect(self.button_exit)
        self.db = Database('restoran.db')
        self.name()

    '''Функция выхода из аккаунта'''
    def button_exit(self):
        QtCore.QCoreApplication.quit()
        status = QtCore.QProcess.startDetached(sys.executable, sys.argv)


    '''Функция вывода фамилии и имени пользователя'''
    def name(self):
        text = self.fio()
        self.fioLable.setText(text)

    '''Функция извлечения личных данных о сотруднике из бд'''
    def fio(self):
        data = self.db.select_two_table_where_data('user', 'user_status', 'fm', 'im', '1')
        if data == []:
            return
        return str(data[0][1]) + ' ' + str(data[0][0])

'''Класс окна администратора'''

class adminwindow(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        uic.loadUi('adminwindow.ui', self)
        self.exitButton.clicked.connect(self.button_exit)
        self.conn = sqlite3.connect('restoran.db')
        self.cursor = self.conn.cursor()
        self.tableView.setSelectionMode(QTableView.SingleSelection)
        self.tableView.setSelectionBehavior(QTableView.SelectRows)
        self.model = QStandardItemModel(self)
        self.tableView.setModel(self.model)
        self.safeButton.clicked.connect(self.update_field)

        # Соединение кнопок с методом load_table для соответствующих названий таблиц
        self.menuButton.clicked.connect(lambda: self.load_table('menu'))
        self.categoryButton.clicked.connect(lambda: self.load_table('categories'))
        self.orderButton.clicked.connect(lambda: self.load_table('list_orders'))
        self.usersButton.clicked.connect(lambda: self.load_table('user'))

    def load_table(self, table_name):
        # Получение данных из базы данных для выбранной таблицы
        self.cursor.execute(f"SELECT * FROM {table_name}")
        data = self.cursor.fetchall()

        # Отображение данных в существующей таблице
        self.display_data_in_table(data)

    def display_data_in_table(self, data):
        # Очистка существующих данных в таблице
        self.model.clear()

        # Заполнение таблицы полученными данными
        for row_num, row_data in enumerate(data):
            for col_num, col_data in enumerate(row_data):
                item = QStandardItem(str(col_data))
                self.model.setItem(row_num, col_num, item)

    def button_exit(self):
        QtCore.QCoreApplication.quit()
        status = QtCore.QProcess.startDetached(sys.executable, sys.argv)

    def update_field(self):
        table_name = self.lineEdit1.text()
        column_name = self.lineEdit2.text()
        field_name = self.lineEdit3.text()
        id = int(self.lineEdit4.text())
        self.update(table_name, column_name, field_name, id)

    def update(self, table_name, column_name, field_name, id):
        update_query = f"UPDATE {table_name} SET {column_name} = ? WHERE id = ?"
        self.cursor.execute(update_query, (field_name, id))
        self.conn.commit()


'''Класс окна о программе'''
class infowindow(QDialog):
    '''Функция инициализации атрибутов класса'''
    def __init__(self, parent=None):
        super().__init__(parent)
        uic.loadUi('infowindow.ui', self)

'''Функция открытия программы'''
if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = MainWindow()
    window.show()
    sys.exit(app.exec_())
