# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'adminwindow.ui'
##
## Created by: Qt User Interface Compiler version 6.6.0
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide6.QtCore import (QCoreApplication, QDate, QDateTime, QLocale,
    QMetaObject, QObject, QPoint, QRect,
    QSize, QTime, QUrl, Qt)
from PySide6.QtGui import (QBrush, QColor, QConicalGradient, QCursor,
    QFont, QFontDatabase, QGradient, QIcon,
    QImage, QKeySequence, QLinearGradient, QPainter,
    QPalette, QPixmap, QRadialGradient, QTransform)
from PySide6.QtWidgets import (QApplication, QDialog, QHBoxLayout, QHeaderView,
    QLineEdit, QPushButton, QSizePolicy, QSpacerItem,
    QTableView, QVBoxLayout, QWidget)
import res4

class Ui_Dialog(object):
    def setupUi(self, Dialog):
        if not Dialog.objectName():
            Dialog.setObjectName(u"Dialog")
        Dialog.resize(914, 582)
        Dialog.setStyleSheet(u"background-color: rgb(18, 25, 27);")
        self.tableView = QTableView(Dialog)
        self.tableView.setObjectName(u"tableView")
        self.tableView.setGeometry(QRect(10, 10, 861, 291))
        self.tableView.setStyleSheet(u"QTableView {\n"
"	background-color: rgb(30, 36, 43);\n"
"	border: 1px solid rgb(30, 36, 43);\n"
"	border-radius: 10px;\n"
"}\n"
"\n"
"QTableView:section {\n"
"}")
        self.widget = QWidget(Dialog)
        self.widget.setObjectName(u"widget")
        self.widget.setGeometry(QRect(20, 322, 401, 241))
        self.horizontalLayout = QHBoxLayout(self.widget)
        self.horizontalLayout.setObjectName(u"horizontalLayout")
        self.horizontalLayout.setContentsMargins(0, 0, 0, 0)
        self.verticalLayout = QVBoxLayout()
        self.verticalLayout.setObjectName(u"verticalLayout")
        self.AddButton_2 = QPushButton(self.widget)
        self.AddButton_2.setObjectName(u"AddButton_2")
        self.AddButton_2.setStyleSheet(u"QPushButton {\n"
"background-color: rgb(30, 36, 43);\n"
"border-radius: 15px;\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"	background-color: rgba(255, 255, 255, 30);\n"
"}\n"
"\n"
"QPushButton:pressed {\n"
"	background-color: rgba(255, 255, 255, 50)\n"
"}")
        icon = QIcon()
        icon.addFile(u":/icons2/icons/ok.svg", QSize(), QIcon.Normal, QIcon.Off)
        self.AddButton_2.setIcon(icon)
        self.AddButton_2.setIconSize(QSize(45, 45))

        self.verticalLayout.addWidget(self.AddButton_2)

        self.AddButton = QPushButton(self.widget)
        self.AddButton.setObjectName(u"AddButton")
        self.AddButton.setStyleSheet(u"QPushButton {\n"
"background-color: rgb(30, 36, 43);\n"
"border-radius: 15px;\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"	background-color: rgba(255, 255, 255, 30);\n"
"}\n"
"\n"
"QPushButton:pressed {\n"
"	background-color: rgba(255, 255, 255, 50)\n"
"}")
        icon1 = QIcon()
        icon1.addFile(u":/icons2/icons/add.svg", QSize(), QIcon.Normal, QIcon.Off)
        self.AddButton.setIcon(icon1)
        self.AddButton.setIconSize(QSize(45, 45))

        self.verticalLayout.addWidget(self.AddButton)

        self.DeleteButton = QPushButton(self.widget)
        self.DeleteButton.setObjectName(u"DeleteButton")
        self.DeleteButton.setStyleSheet(u"QPushButton {\n"
"background-color: rgb(30, 36, 43);\n"
"border-radius: 15px;\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"	background-color: rgba(255, 255, 255, 30);\n"
"}\n"
"\n"
"QPushButton:pressed {\n"
"	background-color: rgba(255, 255, 255, 50)\n"
"}")
        icon2 = QIcon()
        icon2.addFile(u":/icons2/icons/delete.svg", QSize(), QIcon.Normal, QIcon.Off)
        self.DeleteButton.setIcon(icon2)
        self.DeleteButton.setIconSize(QSize(45, 45))

        self.verticalLayout.addWidget(self.DeleteButton)


        self.horizontalLayout.addLayout(self.verticalLayout)

        self.verticalSpacer = QSpacerItem(20, 40, QSizePolicy.Minimum, QSizePolicy.Expanding)

        self.horizontalLayout.addItem(self.verticalSpacer)

        self.verticalLayout_2 = QVBoxLayout()
        self.verticalLayout_2.setObjectName(u"verticalLayout_2")
        self.lineEdit = QLineEdit(self.widget)
        self.lineEdit.setObjectName(u"lineEdit")
        self.lineEdit.setMaximumSize(QSize(788, 16777215))
        font = QFont()
        font.setFamilies([u"Arial"])
        font.setPointSize(16)
        font.setBold(False)
        font.setItalic(False)
        self.lineEdit.setFont(font)
        self.lineEdit.setStyleSheet(u"font: 16pt \"Arial\";\n"
"color: rgb(255, 255, 255);")

        self.verticalLayout_2.addWidget(self.lineEdit)

        self.lineEdit_2 = QLineEdit(self.widget)
        self.lineEdit_2.setObjectName(u"lineEdit_2")
        self.lineEdit_2.setStyleSheet(u"font: 16pt \"Arial\";\n"
"color: rgb(255, 255, 255);")

        self.verticalLayout_2.addWidget(self.lineEdit_2)

        self.lineEdit_3 = QLineEdit(self.widget)
        self.lineEdit_3.setObjectName(u"lineEdit_3")
        self.lineEdit_3.setStyleSheet(u"font: 16pt \"Arial\";\n"
"color: rgb(255, 255, 255);")

        self.verticalLayout_2.addWidget(self.lineEdit_3)

        self.lineEdit_4 = QLineEdit(self.widget)
        self.lineEdit_4.setObjectName(u"lineEdit_4")
        self.lineEdit_4.setStyleSheet(u"font: 16pt \"Arial\";\n"
"color: rgb(255, 255, 255);")

        self.verticalLayout_2.addWidget(self.lineEdit_4)


        self.horizontalLayout.addLayout(self.verticalLayout_2)


        self.retranslateUi(Dialog)

        QMetaObject.connectSlotsByName(Dialog)
    # setupUi

    def retranslateUi(self, Dialog):
        Dialog.setWindowTitle(QCoreApplication.translate("Dialog", u"Dialog", None))
        self.AddButton_2.setText("")
        self.AddButton.setText("")
        self.DeleteButton.setText("")
        self.lineEdit.setPlaceholderText(QCoreApplication.translate("Dialog", u"\u041d\u0430\u0437\u0432\u0430\u043d\u0438\u0435", None))
        self.lineEdit_2.setPlaceholderText(QCoreApplication.translate("Dialog", u"\u041a\u0430\u0442\u0435\u0433\u043e\u0440\u0438\u044f", None))
        self.lineEdit_3.setPlaceholderText(QCoreApplication.translate("Dialog", u"\u041a\u043e\u043b\u0438\u0447\u0435\u0441\u0442\u0432\u043e", None))
        self.lineEdit_4.setText("")
        self.lineEdit_4.setPlaceholderText(QCoreApplication.translate("Dialog", u"\u0426\u0435\u043d\u0430", None))
    # retranslateUi

