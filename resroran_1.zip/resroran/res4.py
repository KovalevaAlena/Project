# Resource object code (Python 3)
# Created by: object code
# Created by: The Resource Compiler for Qt version 6.6.0
# WARNING! All changes made in this file will be lost!

from PySide6 import QtCore

qt_resource_data = b"\
\x00\x00\x03$\
<\
svg version=\x221.1\
\x22 xmlns=\x22http://\
www.w3.org/2000/\
svg\x22 xmlns:xlink\
=\x22http://www.w3.\
org/1999/xlink\x22 \
width=\x2224\x22 heigh\
t=\x2224\x22 viewBox=\x22\
0,0,256,256\x22><g \
fill=\x22#ffffff\x22 f\
ill-rule=\x22nonzer\
o\x22 stroke=\x22none\x22\
 stroke-width=\x221\
\x22 stroke-linecap\
=\x22butt\x22 stroke-l\
inejoin=\x22miter\x22 \
stroke-miterlimi\
t=\x2210\x22 stroke-da\
sharray=\x22\x22 strok\
e-dashoffset=\x220\x22\
 font-family=\x22no\
ne\x22 font-weight=\
\x22none\x22 font-size\
=\x22none\x22 text-anc\
hor=\x22none\x22 style\
=\x22mix-blend-mode\
: normal\x22><g tra\
nsform=\x22translat\
e(0,256) scale(0\
.26667,0.26667)\x22\
><path d=\x22M280,-\
120c-22,0 -40.83\
333,-7.83333 -56\
.5,-23.5c-15.666\
67,-15.66667 -23\
.5,-34.5 -23.5,-\
56.5v-520h-40v-8\
0h200v-40h240v40\
h200v80h-40v520c\
0,22 -7.83333,40\
.83333 -23.5,56.\
5c-15.66667,15.6\
6667 -34.5,23.5 \
-56.5,23.5zM680,\
-720h-400v520h40\
0zM360,-280h80v-\
360h-80zM520,-28\
0h80v-360h-80zM2\
80,-720v520z\x22></\
path></g></g></s\
vg>\
\x00\x00\x029\
<\
svg version=\x221.1\
\x22 xmlns=\x22http://\
www.w3.org/2000/\
svg\x22 xmlns:xlink\
=\x22http://www.w3.\
org/1999/xlink\x22 \
width=\x2224\x22 heigh\
t=\x2224\x22 viewBox=\x22\
0,0,256,256\x22><g \
fill=\x22#ffffff\x22 f\
ill-rule=\x22nonzer\
o\x22 stroke=\x22none\x22\
 stroke-width=\x221\
\x22 stroke-linecap\
=\x22butt\x22 stroke-l\
inejoin=\x22miter\x22 \
stroke-miterlimi\
t=\x2210\x22 stroke-da\
sharray=\x22\x22 strok\
e-dashoffset=\x220\x22\
 font-family=\x22no\
ne\x22 font-weight=\
\x22none\x22 font-size\
=\x22none\x22 text-anc\
hor=\x22none\x22 style\
=\x22mix-blend-mode\
: normal\x22><g tra\
nsform=\x22translat\
e(0,256) scale(0\
.26667,0.26667)\x22\
><path d=\x22M440,-\
440h-240v-80h240\
v-240h80v240h240\
v80h-240v240h-80\
z\x22></path></g></\
g></svg>\
\x00\x00\x02:\
<\
svg version=\x221.1\
\x22 xmlns=\x22http://\
www.w3.org/2000/\
svg\x22 xmlns:xlink\
=\x22http://www.w3.\
org/1999/xlink\x22 \
width=\x2224\x22 heigh\
t=\x2224\x22 viewBox=\x22\
0,0,256,256\x22><g \
fill=\x22#ffffff\x22 f\
ill-rule=\x22nonzer\
o\x22 stroke=\x22none\x22\
 stroke-width=\x221\
\x22 stroke-linecap\
=\x22butt\x22 stroke-l\
inejoin=\x22miter\x22 \
stroke-miterlimi\
t=\x2210\x22 stroke-da\
sharray=\x22\x22 strok\
e-dashoffset=\x220\x22\
 font-family=\x22no\
ne\x22 font-weight=\
\x22none\x22 font-size\
=\x22none\x22 text-anc\
hor=\x22none\x22 style\
=\x22mix-blend-mode\
: normal\x22><g tra\
nsform=\x22translat\
e(0,256.13333) s\
cale(0.26667,0.2\
6667)\x22><path d=\x22\
M382,-240l-228,-\
228l57,-57l171,1\
71l367,-367l57,5\
7z\x22></path></g><\
/g></svg>\
"

qt_resource_name = b"\
\x00\x06\
\x06\xfaec\
\x00i\
\x00c\x00o\x00n\x00s\x003\
\x00\x05\
\x00o\xa6S\
\x00i\
\x00c\x00o\x00n\x00s\
\x00\x0a\
\x0c\xad\x02\x87\
\x00d\
\x00e\x00l\x00e\x00t\x00e\x00.\x00s\x00v\x00g\
\x00\x07\
\x07\xa7Z\x07\
\x00a\
\x00d\x00d\x00.\x00s\x00v\x00g\
\x00\x06\
\x07^Z\xc7\
\x00o\
\x00k\x00.\x00s\x00v\x00g\
"

qt_resource_struct = b"\
\x00\x00\x00\x00\x00\x02\x00\x00\x00\x01\x00\x00\x00\x01\
\x00\x00\x00\x00\x00\x00\x00\x00\
\x00\x00\x00\x00\x00\x02\x00\x00\x00\x01\x00\x00\x00\x02\
\x00\x00\x00\x00\x00\x00\x00\x00\
\x00\x00\x00\x12\x00\x02\x00\x00\x00\x03\x00\x00\x00\x03\
\x00\x00\x00\x00\x00\x00\x00\x00\
\x00\x00\x00P\x00\x00\x00\x00\x00\x01\x00\x00\x05e\
\x00\x00\x01\x8c\x0c\x93_\x08\
\x00\x00\x00<\x00\x00\x00\x00\x00\x01\x00\x00\x03(\
\x00\x00\x01\x8b\xd9\x9c\xb1s\
\x00\x00\x00\x22\x00\x00\x00\x00\x00\x01\x00\x00\x00\x00\
\x00\x00\x01\x8b\xd9\x9c\xea\xf5\
"

def qInitResources():
    QtCore.qRegisterResourceData(0x03, qt_resource_struct, qt_resource_name, qt_resource_data)

def qCleanupResources():
    QtCore.qUnregisterResourceData(0x03, qt_resource_struct, qt_resource_name, qt_resource_data)

qInitResources()
