3# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'ProfilWindow.ui'
##
## Created by: Qt User Interface Compiler version 6.6.0
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide6.QtCore import (QCoreApplication, QDate, QDateTime, QLocale,
    QMetaObject, QObject, QPoint, QRect,
    QSize, QTime, QUrl, Qt)
from PySide6.QtGui import (QBrush, QColor, QConicalGradient, QCursor,
    QFont, QFontDatabase, QGradient, QIcon,
    QImage, QKeySequence, QLinearGradient, QPainter,
    QPalette, QPixmap, QRadialGradient, QTransform)
from PySide6.QtWidgets import (QApplication, QCalendarWidget, QDateEdit, QDialog,
    QGridLayout, QLabel, QPushButton, QSizePolicy,
    QWidget)
import res3_rc
import res2_rc

class Ui_Dialog(object):
    def setupUi(self, Dialog):
        if not Dialog.objectName():
            Dialog.setObjectName(u"Dialog")
        Dialog.resize(685, 460)
        Dialog.setStyleSheet(u"background-color: rgb(18, 25, 27);")
        self.widget = QWidget(Dialog)
        self.widget.setObjectName(u"widget")
        self.widget.setGeometry(QRect(15, 15, 661, 431))
        self.gridLayout = QGridLayout(self.widget)
        self.gridLayout.setObjectName(u"gridLayout")
        self.gridLayout.setContentsMargins(0, 0, 0, 0)
        self.pushButton_4 = QPushButton(self.widget)
        self.pushButton_4.setObjectName(u"pushButton_4")
        self.pushButton_4.setStyleSheet(u"QPushButton {\n"
"background-color: rgb(30, 36, 43);\n"
"border-radius: 15px;\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"	background-color: rgba(255, 255, 255, 30);\n"
"}\n"
"\n"
"QPushButton:pressed {\n"
"	background-color: rgba(255, 255, 255, 50)\n"
"}")
        icon = QIcon()
        icon.addFile(u":/icons2/icons/back.svg", QSize(), QIcon.Normal, QIcon.Off)
        self.pushButton_4.setIcon(icon)
        self.pushButton_4.setIconSize(QSize(45, 45))

        self.gridLayout.addWidget(self.pushButton_4, 0, 0, 1, 1)

        self.calendarWidget = QCalendarWidget(self.widget)
        self.calendarWidget.setObjectName(u"calendarWidget")
        self.calendarWidget.setStyleSheet(u"background-color: rgb(30, 36, 43);\n"
"border-radius: 30px;")
        self.calendarWidget.setDateEditEnabled(True)

        self.gridLayout.addWidget(self.calendarWidget, 0, 1, 4, 1)

        self.label = QLabel(self.widget)
        self.label.setObjectName(u"label")
        self.label.setStyleSheet(u"background-color: rgb(30, 36, 43);\n"
"color: rgb(255, 255, 255);\n"
"font: 700 14pt \"Arial\";\n"
"border-radius: 8px;")

        self.gridLayout.addWidget(self.label, 1, 0, 1, 1)

        self.label_2 = QLabel(self.widget)
        self.label_2.setObjectName(u"label_2")
        self.label_2.setStyleSheet(u"background-color: rgb(30, 36, 43);\n"
"color: rgb(255, 255, 255);\n"
"font: 700 14pt \"Arial\";\n"
"border-radius: 8px;")

        self.gridLayout.addWidget(self.label_2, 2, 0, 1, 1)

        self.pushButton = QPushButton(self.widget)
        self.pushButton.setObjectName(u"pushButton")
        self.pushButton.setStyleSheet(u"QPushButton {\n"
"background-color:rgb(0, 218, 160);\n"
"border-style: outset; \n"
"border-radius: 15px; \n"
"border-color: rgb(0, 255, 191);\n"
"font: 700 14pt \"Arial\";\n"
"color: rgb(255, 255, 255);\n"
"padding: 4px; \n"
"}\n"
"\n"
"QPushButton:hover {\n"
"	background-color: rgb(0, 239, 175);\n"
"}\n"
"\n"
"QPushButton:pressed {\n"
"	background-color: rgb(0, 255, 187);\n"
"}")

        self.gridLayout.addWidget(self.pushButton, 3, 0, 1, 1)

        self.label_3 = QLabel(self.widget)
        self.label_3.setObjectName(u"label_3")
        self.label_3.setStyleSheet(u"background-color: rgb(30, 36, 43);\n"
"color: rgb(255, 255, 255);\n"
"font: 700 14pt \"Arial\";\n"
"border-radius: 8px;")

        self.gridLayout.addWidget(self.label_3, 4, 1, 1, 1)

        self.dateEdit = QDateEdit(self.widget)
        self.dateEdit.setObjectName(u"dateEdit")
        self.dateEdit.setStyleSheet(u"background-color: rgb(30, 36, 43);\n"
"color: rgb(255, 255, 255);\n"
"font: 700 14pt \"Arial\";")

        self.gridLayout.addWidget(self.dateEdit, 5, 1, 1, 1)

        self.pushButton_2 = QPushButton(self.widget)
        self.pushButton_2.setObjectName(u"pushButton_2")
        self.pushButton_2.setStyleSheet(u"QPushButton {\n"
"background-color: rgb(30, 36, 43);\n"
"border-radius: 15px;\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"	background-color: rgba(255, 255, 255, 30);\n"
"}\n"
"\n"
"QPushButton:pressed {\n"
"	background-color: rgba(255, 255, 255, 50)\n"
"}")

        self.gridLayout.addWidget(self.pushButton_2, 6, 1, 1, 1)


        self.retranslateUi(Dialog)

        QMetaObject.connectSlotsByName(Dialog)
    # setupUi

    def retranslateUi(self, Dialog):
        Dialog.setWindowTitle(QCoreApplication.translate("Dialog", u"Dialog", None))
        self.pushButton_4.setText("")
        self.label.setText(QCoreApplication.translate("Dialog", u"TextLabel", None))
        self.label_2.setText(QCoreApplication.translate("Dialog", u"TextLabel", None))
        self.pushButton.setText(QCoreApplication.translate("Dialog", u"\u041e\u0442\u043a\u0440\u044b\u0442\u044c \u0441\u043c\u0435\u043d\u0443", None))
        self.label_3.setText(QCoreApplication.translate("Dialog", u"TextLabel", None))
        self.pushButton_2.setText(QCoreApplication.translate("Dialog", u"PushButton", None))
    # retranslateUi

